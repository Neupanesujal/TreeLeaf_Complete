# character > 2024-12-03 11:25pm
https://universe.roboflow.com/sujal-v2krc/character-vluic

Provided by a Roboflow user
License: CC BY 4.0

