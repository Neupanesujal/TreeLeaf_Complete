# Liscence plate > 2024-08-29 8:19am
https://universe.roboflow.com/sujal-v2krc/liscence-plate-btlfl

Provided by a Roboflow user
License: CC BY 4.0

